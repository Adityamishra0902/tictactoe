package com.example.adityatictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    int player= 1;
    int [][]winingstates={{0,1,2},{3,4,5},{6,7,8}};
    int []gamestates={-1,-1,-1,-1,-1,-1,-1,-1,-1};
    public void load(View view){
        ImageView v=(ImageView) view;
        int tag=Integer.parseInt(v.getTag().toString());
        if (player == 1) {
            v.setImageResource(R.drawable.cross);
            Toast.makeText(this,tag+""+"Cross",Toast.LENGTH_SHORT).show();
           // gamestates[tag-1]=player;
            player = 0;
        }
        else
        {
            v.setImageResource(R.drawable.zero);
            Toast.makeText(this,tag+""+"Zero",Toast.LENGTH_SHORT).show();
            //gamestates[tag-1]=player;
            player=1;
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}